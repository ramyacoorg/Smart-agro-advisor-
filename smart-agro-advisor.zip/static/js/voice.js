const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

if (SpeechRecognition) {
    const recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.continuous = false;
    recognition.interimResults = false;

    const voiceBtn = document.getElementById('start-voice-btn');
    const voiceStatus = document.getElementById('voice-status');

    if (voiceBtn) {
        voiceBtn.addEventListener('click', () => {
            recognition.start();
            if (voiceStatus) voiceStatus.innerText = "Listening... Speak now.";
        });

        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript.toLowerCase();
            if (voiceStatus) voiceStatus.innerText = `Heard: "${transcript}"`;
            
            // Basic parsing for demo purposes
            const numbers = transcript.match(/\d+/g);
            if (numbers && numbers.length >= 1) {
                const inputs = document.querySelectorAll('.agro-form input[type="number"]');
                if (inputs.length > 0) {
                    inputs.forEach((input, index) => {
                        if (numbers[index]) {
                            input.value = numbers[index];
                        }
                    });
                }
            }
            speakText(`Processed voice input: ${transcript}`);
        };

        recognition.onerror = (event) => {
            if (voiceStatus) voiceStatus.innerText = "Error occurred in recognition: " + event.error;
        };
    }
} else {
    const voiceBtn = document.getElementById('start-voice-btn');
    if (voiceBtn) {
        voiceBtn.style.display = 'none';
    }
}

function speakText(text) {
    if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text);
        window.speechSynthesis.speak(utterance);
    }
}
