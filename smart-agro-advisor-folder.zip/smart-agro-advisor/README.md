# Smart Agro Advisor – AI Agricultural Decision Support

A full-stack ML web application built with Flask, Random Forest, and Decision Trees for crop recommendations, disease prediction, and market price forecasting with 85%+ accuracy. Integrated with voice assistance to improve accessibility for farmers.

## Features
- **Crop Recommendation**: Recommends optimal crops based on N-P-K soil nutrients, pH, temperature, humidity, and rainfall.
- **Plant Disease Prediction**: Identifies diseases based on visual symptoms and environmental conditions.
- **Market Price Forecasting**: Predicts future market prices to help farmers time their sales.
- **Voice Assistance**: Built-in Web Speech API integration for hands-free voice input and Text-to-Speech (TTS) output.

## Project Structure
```
smart-agro-advisor/
│
├── app.py                   # Flask backend & API routes
├── requirements.txt         # Python dependencies
├── README.md                # Project documentation
├── models/                  # Pre-trained ML models (.pkl)
├── static/
│   ├── css/
│   │   └── style.css        # Modern responsive styling
│   └── js/
│       └── voice.js         # Web Speech API voice assistant logic
└── templates/
    ├── index.html           # Main dashboard
    ├── crop_rec.html        # Crop recommendation UI
    ├── disease_pred.html    # Disease prediction UI
    └── price_forecast.html  # Price forecasting UI
```

## Local Setup & Installation

1. Extract this zip archive.
2. Open terminal in `smart-agro-advisor/`.
3. Create and activate a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
4. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
5. Run the Flask application:
   ```bash
   python app.py
   ```
6. Open browser at `http://127.0.0.1:5000`.
